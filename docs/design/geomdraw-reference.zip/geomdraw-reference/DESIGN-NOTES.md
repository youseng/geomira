# Geomdraw design reference (for Geomira's UI design pass)

Geomdraw is the maintainer's earlier prototype. Its UI is the target look and feel for
Geomira. Its JavaScript logic must NOT be reused (Geomira's logic lives in the packages).

## Files

- `geomdraw.html`: the whole old app (open it in a browser). Reuse its CSS, colours,
  typography, layout and SVG/Unicode tool icons. The maintainer owns this code.
- `screenshots/`:
  - 01-main-default.png: first screen.
  - 02-desktop-ninepoint.png, 02-wide-ninepoint.png: a figure at 1280×720 and 1600×900.
  - 03-claims-panel.png: claim cards, live claim chips on the canvas, status line.
  - 04-examples-menu.png, 05-export-menu.png: top-bar menus.
  - 06-mobile.png: phone layout (390×664 @2x): compact icon top bar, horizontal tool
    strip at the bottom with group labels, command line below it.

## What to copy

- Layout: brand at top left ("Geom" upright + italic serif part), icon top bar
  (undo/redo, Randomize + triangle type, claim box + Test, View / Examples / Export menus,
  settings, help); left tool palette in labelled groups (POINTS, LINES, CIRCLES, CENTERS…)
  with a shortcut letter under each icon; right panel with tabs; zoom and fit buttons
  floating at the bottom right of the canvas; status line ("Move / select") at the bottom
  left of the canvas; command line along the bottom.
- Colours (CSS variables in geomdraw.html `:root`): --bg #f4f4f2, --panel #ffffff,
  --border #dcdcd6, --text #1d1d1b, --muted #6b6b66, --accent #2f5fb3,
  --accent-soft #e6edf9, --ok #2e7d32 / --ok-soft #e7f3e8, --amber #a76a00 /
  --amber-soft #fbf1dc, --bad #b3261e / --bad-soft #fbe9e7, highlighted line #1f6fd1.
- Type: system-ui for the UI; serif math labels in italic (Latin Modern Roman / CMU Serif /
  Times), monospace for verdict details.
- Canvas: italic serif point labels, small black points, thin strokes, auxiliary circles
  dashed grey, highlighted lines blue; selected objects ringed in light blue.
- Claims: cards with the claim in italic math, a green pill for the current figure
  ("true here · err 5.2e-17"), small buttons under it, monospace detail lines; live claim
  chips (green pills) at the bottom left of the canvas.
- Phone: icon-only top bar, horizontal scrolling tool strip with vertical group labels,
  command line at the bottom, zoom buttons on the canvas.

## What NOT to copy (later runs or Geomdraw-only)

- "What's special?", Steps, Findings, Solution, Bash, Inversion, Coords tabs, "prove
  symbolically", projective views, problem library, handouts: these belong to Phase 2
  runs. Leave room; no stubs or dead buttons.
- Geomdraw's wording "holds generically" and "prove symbolically": Geomira's verdict
  wording is fixed by SPEC §10.5 and never says "proved" in v1.
